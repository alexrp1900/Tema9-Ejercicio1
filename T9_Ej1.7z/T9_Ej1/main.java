package T9_Ej1;

public class main {

	public static void main(String[] args) {
		
		Software s1 = new Software('B', "Bonito", "ProgramaJuegos");
		Software s2 = new Software('B', "Bonito", "Juego");
		
		System.out.println("Cuesta "+s1.getPrecio()+" euros");
		System.out.println("Cuesta "+s2.getPrecio()+" euros");
		
		Hardware h1 = new Hardware('A', "raton", true);
		Hardware h2 = new Hardware('A', "raton", false);
		
		System.out.println("Cuesta "+h1.getPrecio()+" euros");
		System.out.println("Cuesta "+h2.getPrecio()+" euros");
	}

}
