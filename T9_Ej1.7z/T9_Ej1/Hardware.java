package T9_Ej1;

public class Hardware extends Producto {

	private boolean periferico;

	public Hardware(char codigo, String descripcion, boolean periferico) {
		super(codigo, descripcion);

		this.periferico = periferico;

	}

	public boolean isPeriferico() {
		return periferico;
	}

	public void setPeriferico(boolean periferico) {
		this.periferico = periferico;
	}

	@Override
	public double getPrecio() {
		double precioFinal = 0;
		if (this.getCodigo() == 'A') {
			if (this.periferico == true) {
				precioFinal = A + ((A * 10) / 100);
			} else {
				precioFinal = A;
			}
		}
		if (this.getCodigo() == 'B') {
			if (this.periferico == true) {
				precioFinal = B + ((B * 10) / 100);
			} else {
				precioFinal = B;
			}
		}
		return precioFinal;
	}

	
}
