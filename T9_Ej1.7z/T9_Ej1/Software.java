package T9_Ej1;

public class Software extends Producto {

	private String tipo;

	public Software(char codigo, String descripcion, String tipo) {
		super(codigo, descripcion);

		this.tipo = tipo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public double getPrecio() {
		double precioFinal = 0;
		if (this.getCodigo() == 'B') {
			if (this.tipo == "ProgramaJuegos") {
				precioFinal = B + ((B * 5) / 100);
			} else {
				precioFinal = B;
			}
		}
		if (this.getCodigo() == 'C') {
			if (this.tipo == "ProgramaJuegos") {
				precioFinal = C + ((C * 5) / 100);
			} else {
				precioFinal = C;
			}
		}
		return precioFinal;

	}
}